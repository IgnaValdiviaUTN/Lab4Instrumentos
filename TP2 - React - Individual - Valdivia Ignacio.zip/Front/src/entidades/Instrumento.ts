export default class Instrumento{
    id:string = ""; //number
	instrumento:string = "";
	marca:string = "";
	modelo:string = "";
    imagen:string = "";
	precio:string = ""; //number
	costoEnvio:string = ""; //number
	cantidadVendida:string = ""; //number
	descripcion:string = "";
}