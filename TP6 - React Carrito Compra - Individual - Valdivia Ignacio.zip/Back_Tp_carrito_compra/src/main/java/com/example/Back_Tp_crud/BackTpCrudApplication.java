package com.example.Back_Tp_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackTpCrudApplication {

	public static void main(String[] args) {

		SpringApplication.run(BackTpCrudApplication.class, args);
		System.out.println("Backend Funcionando...");
	}

}
