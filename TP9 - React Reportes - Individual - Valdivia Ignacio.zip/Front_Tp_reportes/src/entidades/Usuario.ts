export default class Usuario {
    id?:number;
    nombreUsuario: string = "";
    clave: string = "";
    rol?:string = "";
}