export enum Roles{
    ADMIN ='ADMIN',
    USER = 'VISOR'
}