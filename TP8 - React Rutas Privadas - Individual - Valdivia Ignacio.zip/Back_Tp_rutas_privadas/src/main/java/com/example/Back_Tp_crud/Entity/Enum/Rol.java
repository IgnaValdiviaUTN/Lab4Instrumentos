package com.example.Back_Tp_crud.Entity.Enum;

public enum Rol {
    ADMIN,
    OPERADOR,
    VISOR
}
