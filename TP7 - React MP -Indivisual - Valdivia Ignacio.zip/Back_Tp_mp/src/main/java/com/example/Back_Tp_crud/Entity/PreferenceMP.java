package com.example.Back_Tp_crud.Entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PreferenceMP {
    private String id;
    private Integer statusCode;
}
