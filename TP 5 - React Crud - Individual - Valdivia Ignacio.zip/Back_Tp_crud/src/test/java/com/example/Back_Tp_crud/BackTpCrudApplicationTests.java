package com.example.Back_Tp_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackTpCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
